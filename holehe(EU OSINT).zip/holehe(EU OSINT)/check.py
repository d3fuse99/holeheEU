import os
import sys
import subprocess

def main():
    if len(sys.argv) < 2:
        print("Использование: python check.py почта [d]")
        return

    email = sys.argv[1]
    # Если вторым аргументом идет 'd', передаем его в основной скрипт
    mode = "d" if (len(sys.argv) > 2 and sys.argv[2] == "d") else ""

    # Определяем пути
    base_dir = os.path.dirname(os.path.abspath(__file__))
    project_dir = os.path.join(base_dir, "holehe-master")
    run_script = os.path.join(project_dir, "run.py")

    # Устанавливаем PYTHONPATH, чтобы Python видел папку holehe
    env = os.environ.copy()
    env["PYTHONPATH"] = project_dir

    # Формируем команду
    cmd = [sys.executable, run_script, email]
    if mode:
        cmd.append(mode)

    # Запускаем
    subprocess.run(cmd, env=env)

if __name__ == "__main__":
    main()