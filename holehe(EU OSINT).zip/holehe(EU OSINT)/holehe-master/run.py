import trio
import httpx
import sys
import urllib3
import random
from holehe.core import import_submodules
from tqdm import tqdm

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

async def safe_check(func, email, client, out, mode, pbar):
    module_name = func.__name__
    try:
        if mode == "deep":
            await trio.sleep(random.uniform(1.5, 3.5))
            t_limit = 30
        else:
            t_limit = 12

        with trio.move_on_after(t_limit):
            await func(email, client, out)
        
        res = next((item for item in reversed(out) if item['name'] == module_name), None)
        
        status = "[+]" if res and res['exists'] else "[-]" if res else "[L]"
        label = "EXISTS" if status == "[+]" else "not found" if status == "[-]" else "LIMIT"

        pbar.write(f"{status} {module_name:<15} | {label}")
        pbar.update(1)
    except Exception:
        pbar.update(1)

async def check_email(email, mode):
    out = []
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
        'Accept-Language': 'en-US,en;q=0.9,ru;q=0.8'
    }
    
    limits = httpx.Limits(max_connections=5 if mode == "deep" else 20, max_keepalive_connections=2)
    
    async with httpx.AsyncClient(headers=headers, verify=False, timeout=20, limits=limits) as client:
        print(f"\n--- TARGET: {email} | MODE: {mode.upper()} ---\n")
        
        try:
            modules_dict = import_submodules("holehe.modules")
        except Exception as e:
            print(f"Error loading modules: {e}")
            return

        all_funcs = [getattr(obj, name.split(".")[-1]) for name, obj in modules_dict.items() if hasattr(obj, name.split(".")[-1])]

        with tqdm(total=len(all_funcs), desc="Scanning", unit="site", colour="green") as pbar:
            async with trio.open_nursery() as nursery:
                for func in all_funcs:
                    nursery.start_soon(safe_check, func, email, client, out, mode, pbar)

    print("\n" + "="*45 + "\nFINAL REPORT (FOUND):")
    found = [r for r in out if r.get('exists')]
    if found:
        for r in found:
            print(f"[+] {r['name']:<15} | {r['domain']}")
    else:
        print("No accounts found.")
    print("="*45)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit()
    
    email_to_check = sys.argv[1]
    run_mode = "deep" if (len(sys.argv) > 2 and sys.argv[2] == "d") else "fast"
    
    trio.run(check_email, email_to_check, run_mode)